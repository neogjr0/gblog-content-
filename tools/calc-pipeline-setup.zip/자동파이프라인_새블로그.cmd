﻿@echo off
title Calc-Note Auto Publish (새 블로그)
cd /d "%~dp0"
if not exist inbox mkdir inbox
if not exist queue mkdir queue
echo.
echo  ============================================
echo   새 블로그(calc-note) 자동 발행 - 창 1개만
echo.
echo   * calc-*.zip 을 자동으로 찾아 설치합니다
echo     (다운로드 / 바탕화면 / 문서 / Telegram)
echo   * 하루 2편, 3시간 간격으로 발행됩니다
echo  ============================================
echo.
node publish-local.js --watch
pause
