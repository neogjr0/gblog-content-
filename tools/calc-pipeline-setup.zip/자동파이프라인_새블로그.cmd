﻿@echo off
title Calc-Note Auto Publish (새 블로그)
cd /d "%~dp0"
if not exist inbox mkdir inbox
if not exist queue mkdir queue
echo.
echo  ============================================
echo   새 블로그(calc-note) 자동 발행 파이프라인
echo   감시 파일: calc-*.zip 만 (기존 파이프라인과 충돌 없음)
echo  ============================================
echo.
start "1-file-installer-newblog" cmd /k powershell -NoProfile -ExecutionPolicy Bypass -Command "$q=Join-Path '%~dp0' 'queue'; $inbox=Join-Path '%~dp0' 'inbox'; $roots=@($inbox); $users=Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue; foreach($u in $users){ if($u.Name -eq 'Public' -or $u.Name -eq 'Default' -or $u.Name -eq 'All Users'){continue}; $roots+=(Join-Path $u.FullName 'Downloads'); $roots+=(Join-Path $u.FullName 'Documents'); $roots+=(Join-Path $u.FullName 'Desktop'); $roots+=(Join-Path (Join-Path $u.FullName 'Downloads') 'Telegram Desktop') }; $roots=$roots|Select-Object -Unique; foreach($p in $roots){ if(Test-Path $p){ Write-Host ('[WATCH] '+$p) -ForegroundColor Cyan } }; Write-Host '[RULE] calc-*.zip 만 설치됩니다' -ForegroundColor Cyan; while($true){ foreach($p in $roots){ if(Test-Path $p){ Get-ChildItem -Path $p -Filter calc-*.zip -ErrorAction SilentlyContinue | ForEach-Object { try { Expand-Archive -Path $_.FullName -DestinationPath $q -Force; Write-Host ('[INSTALLED] '+$_.Name) -ForegroundColor Green; Remove-Item $_.FullName -Force } catch { Write-Host ('[WAIT/FAIL] '+$_.Name+' - '+$_.Exception.Message) -ForegroundColor Yellow } } } }; Start-Sleep -Seconds 5 }"
start "2-publisher-newblog" cmd /k node publish-local.js --watch
exit
