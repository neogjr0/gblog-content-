@echo off
title Recipe Blog Auto Publish (soeasycook)
cd /d "%~dp0"
if not exist inbox mkdir inbox
if not exist queue mkdir queue
echo.
echo  ============================================
echo   RECIPE BLOG (soeasycook) AUTO PUBLISH
echo   * auto-installs recipe-*.zip
echo     (Downloads / Desktop / Documents / Telegram)
echo   * max 2 posts per day, 10-min gap
echo   ============================================
echo.
node publish-local.js --watch
pause
